#!/bin/bash
set -e

#source ./variables.sh
# CURRENT_DATE=$(date +%Y%m%d)
CURRENT_DATE="${1}" # taking this value from main.sh
ORIGINAL_FOLDER_PATH="/opt"
# FOLDER_NAME="oneload"
FOLDER_NAME="${2}" # taking this value from main.sh
# NEW_FOLDER_BASE_PATH="/home/munawar"
NEW_FOLDER_BASE_PATH="${3}" # taking this value from main.sh
NEW_FOLDER_PATH="${NEW_FOLDER_BASE_PATH}/${FOLDER_NAME}-${CURRENT_DATE}"
DEPLOYMENTS_FOLDER="deployments"
CONFIGURATION_FOLDER="config"
PROFILES_PATH="config/profiles"
SOURCE_MACHINE="${4}" # taking this value from main.sh
ENV_NAME="${5}" # taking this value from main.sh

# ENV_NAME="qa1"
# SOURCE_MACHINE=(
#     "10.130.21.21"
#     "10.130.21.22"
#     "10.130.21.23"
#     "10.130.21.24"
#     "10.130.21.25"
#     "10.130.21.26"
#     "10.130.21.27"
#     )

# List of patterns to process
EXTRA_FILES=("*.jar.*" "*.jar_*" "*.jar-*" "*.out*" "*.properties.*" "*.properties-*" "*.properties_*" "*.yml.*" "*.yml-*" "*.yml_*" "*.tar*" )

backup_folder() {
    echo "######### Folder Backup Function #########"
    cp -r "${ORIGINAL_FOLDER_PATH}/${FOLDER_NAME}" "${NEW_FOLDER_PATH}"
}

delete_extra_files() {
    echo "######### Deleting Extra Files #########"

    # Remove extra files in deployments folder
    for EXTRA_FILE in "${EXTRA_FILES[@]}"; do
        find "${NEW_FOLDER_PATH}" -type f -name "${EXTRA_FILE}" -delete
    done
    echo "## All extra files have been deleted ##"
}

create_tar_file() {
    echo "######### Create Tar File #########"
    cd "${NEW_FOLDER_BASE_PATH}"
    # tar czf "${FOLDER_NAME}-${CURRENT_DATE}-${SOURCE_MACHINE}-${ENV_NAME}".tar.gz "${FOLDER_NAME}-${CURRENT_DATE}"
    tar cvf "${FOLDER_NAME}-${CURRENT_DATE}".tar "${FOLDER_NAME}-${CURRENT_DATE}"
}

# Execute all functions
backup_folder
delete_extra_files
create_tar_file
