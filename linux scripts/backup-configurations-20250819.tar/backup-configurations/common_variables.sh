#!/bin/bash

CURRENT_DATE=$(date +%Y%m%d)
FOLDER_NAME="oneload"
NEW_FOLDER_BASE_PATH="/home/munawar"
