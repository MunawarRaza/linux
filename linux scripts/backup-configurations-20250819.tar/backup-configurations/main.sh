#!/bin/bash
set -x

echo "####### Job Started at $(date +%Y%m%d-%H%M%S) #######"

echo "#### Configuration Backup ####"
# cd /home/munawar/ansible/backup-configurations/

## Variables
SCRIPT_DIR=$(dirname $0)
ANSIBLE_PLAYBOOK="${SCRIPT_DIR}/main.yml"
REMOTE_USER="munawar"

ENV_NAME=("dev" "qa1" "qa2" "uat")
DEV_IPS=("10.130.21.21" "10.130.21.22" "10.130.21.23" "10.130.21.24" "10.130.21.25" "10.130.21.26")
QA1_IPS=("10.130.22.21" "10.130.22.22" "10.130.22.23" "10.130.22.24" "10.130.22.25" "10.130.22.26")
QA2_IPS=("10.130.23.21" "10.130.23.22" "10.130.23.23" "10.130.23.24" "10.130.23.25" "10.130.23.26")
UAT_IPS=("10.30.22.21" "10.30.22.22" "10.30.22.23" "10.30.22.24" "10.30.22.25" "10.30.22.26")

# QA2_IPS=("10.130.23.21" "10.130.23.22" "10.130.23.23" "10.130.23.24" "10.130.23.25" "10.130.23.26")

# source ./common_variables.sh

CURRENT_DATE=$(date +%Y%m%d)
FOLDER_NAME="oneload"
NEW_FOLDER_BASE_PATH="/home/munawar"
ANSIBLE_SSH_PASS="Oneload!.068"
ANSIBLE_BECOME_PASS="Oneload!.068"

ansible_function() {
    ansible-playbook "${ANSIBLE_PLAYBOOK}" \
    -i "${SOURCE_MACHINE}," \
    -u "${REMOTE_USER}" \
    -e SOURCE_MACHINE="${SOURCE_MACHINE}" \
    -e TARGET_MACHINE="${TARGET_MACHINE}" \
    -e ansible_ssh_pass="${ANSIBLE_SSH_PASS}" \
    -e ansible_become_pass="${ANSIBLE_BECOME_PASS}" \
    -e REMOTE_USER="${REMOTE_USER}" \
    -e CURRENT_DATE="${CURRENT_DATE}" \
    -e FOLDER_NAME="${FOLDER_NAME}" \
    -e NEW_FOLDER_BASE_PATH="${NEW_FOLDER_BASE_PATH}" \
    -e ENV_NAME="${ENV}"

    if [ $? -ne 0 ]; then
        echo "❌ ERROR: ${ENV} -> ${SOURCE_MACHINE} failed"
        FAILED_HOSTS+=("${ENV}:${SOURCE_MACHINE}")
    fi
}


sync_environment() {
    for ENV in "${ENV_NAME[@]}"; do
        if [ ${ENV} == 'dev' ]; then
            for SOURCE_MACHINE in "${DEV_IPS[@]}"; do
                ansible_function
            done
        elif [ ${ENV} == 'qa1' ]; then
            for SOURCE_MACHINE in "${QA1_IPS[@]}"; do
                ansible_function
            done
        elif [ ${ENV} == 'qa2' ]; then
            for SOURCE_MACHINE in "${QA2_IPS[@]}"; do
                ansible_function
            done
        elif [ ${ENV} == 'uat' ]; then
            for SOURCE_MACHINE in "${UAT_IPS[@]}"; do
                ansible_function
            done
        else
            echo "⚠️ Invalid environment: ${ENV}"
        fi
    done
}

sync_environment
if [ ${#FAILED_HOSTS[@]} -gt 0 ]; then
    echo "Sending failure notification..."
    ${SCRIPT_DIR}/notification.sh "${CURRENT_DATE}" "FAILED_HOSTS: ${FAILED_HOSTS[*]}"
else
    ${SCRIPT_DIR}/notification.sh "${CURRENT_DATE}" "All environments successful"
fi
echo "####### Job Completed at $(date +%Y%m%d-%H%M%S) #######"
